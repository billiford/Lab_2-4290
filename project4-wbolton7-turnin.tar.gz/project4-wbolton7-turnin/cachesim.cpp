#include "cachesim.hpp"
#include <math.h>
#include <stdio.h>
#include <vector>


/**
 * This struct is used to store the stats of the cache being run in the simulator.
 */
struct Cache_Stats {
	uint64_t c;
	uint64_t b;
	uint64_t s;
	char st;
	char r;
};

/**
 * Each cache entry is stored in a struct that contains its tag, index, offset, and validity.
 */
struct Cache_Entry {
	uint64_t tag;
	uint64_t index;
	uint64_t offset;
	bool valid;
};

/**
 * To implement the cache and victim cache (which I did not get around to) I use vectors of
 * cache entries - I create a 2d vector for the cache which is set up as vector[#sets][#blocks per set].
 */
typedef std::vector<std::vector<Cache_Entry> > Matrix;
typedef std::vector<Cache_Entry> Row;
typedef std::vector<std::vector<uint64_t>> LRU_Matrix;
typedef std::vector<uint64_t> LRU_Matrix_Line;

static Matrix cache;
static LRU_Matrix lru_matrix;
static Row victim_cache;
static Cache_Stats cache_stats;
static uint64_t index_offset_bits, index_bits, offset_bits;

/**
 * update_lru is used to changes the index of the the most recently used cache entry.
 * lru_matrix is a matrix of the form vector[#sets][#blocks per set]. The entry stored at
 * vector[set][0] is the least recently used for that specific set in the cache.
 */
void update_lru(uint64_t index, uint64_t s, uint64_t lru_index) {
	for (uint64_t i = 0; i < pow(2, s); i++) {
		if (lru_matrix[index][i] == lru_index) {
			for (uint64_t j = i; j < pow(2, s); j++) {
				lru_matrix[index][j] = lru_matrix[index][j + 1];
			}
			lru_matrix[index][pow(2, s) - 1] = lru_index;
		}
	}
}

/**
 * Address is of the form: | tag | index | offset |. I store the index, and offset bits
 * in global variables offset_bits and index_bits. b is the number of bytes in the block,
 * so the offset can be calculated by taking 2^b - 1 (to get all 1s for the offset bits)
 * and then performing a logical and with the address. likewise, 2^(c - b - s) - 1 will
 * give all ones for the index bits (address must be shifted right by b bits, then
 * logical and). the global variable index_offset_bits is calculated as c - s, which is
 * this total number of bits for both the index and offset combined. This is used to 
 * get the tag (address can be simply shifted right this amount).
 *
 * I then initialize the victim cache (not used) and the actual cache, along with
 * the lru_matrix which is used to calculate the index of the lru cache entry.
 */
void setup_cache(uint64_t c, uint64_t b, uint64_t s, uint64_t v, char st, char r) {
	offset_bits = pow(2, b) - 1;
	index_bits = pow(2, c - b - s) - 1;
	index_offset_bits = c - s;

	cache_stats = {c, b, s, st, r};

	for (int i = 0; i < pow(2, v); i++) {
		Cache_Entry entry = {0, 0, 0, false};
		victim_cache.push_back(entry);
	}

	for (uint64_t i = 0; i < index_bits + 1; i++) {
		std::vector<Cache_Entry> entry;
		cache.push_back(entry);
	}

	for (uint64_t i = 0; i < index_bits + 1; i++) {
		LRU_Matrix_Line lru_matrix_line(pow(2, s));
		lru_matrix.push_back(lru_matrix_line);
		for (uint64_t j = 0; j < pow(2, s); j++) {
			lru_matrix[i].push_back(j);
		}
		Cache_Entry entry = {0, 0, 0, false};
		cache[i].push_back(entry);
		
	}
}
/**
 * First, index, tag, and offset are calculated as mentioned in the setup_cache
 * comment. I increment p_stats->accesses. If rw is read, increment read,
 * then check the cache at the current set index (cycle through the whole set)
 * to see if set contains the tag and the index is valid. If it is, set a bool variable
 * hit to true. If hit is not true, increment p_stats->read_misses, find the lru_index
 * by getting the index from the lru_matrix, set the cache at that index with the current
 * entry, then update the lru vector table. I perform the same operations is rw is write.
 * At the end, if hit is false, increment p_stats->misses. I'm sure not all of this is 
 * correct and I'm missing some points, but this is as far as I could get.
 */
void cache_access(char rw, uint64_t address, cache_stats_t* p_stats) {
	bool hit = false;
	uint64_t index = (address >> cache_stats.b) & index_bits;
	uint64_t tag = address >> index_offset_bits;
	uint64_t offset = address & offset_bits;

	p_stats->accesses++;

	if (rw == 'r') {
		p_stats->reads++;
		for (int i = 0; i < pow(2, cache_stats.s); i++) {
			if (cache[index][i].tag == tag && cache[index][i].valid)
				hit = true;
		}
		if (!hit) {
			p_stats->read_misses++;

			uint64_t lru_index = lru_matrix.at(index).at(0);

			cache[index][lru_index].tag = tag;
			cache[index][lru_index].index = index;
			cache[index][lru_index].offset = offset;
			cache[index][lru_index].valid = true;
			update_lru(index, cache_stats.s, lru_index);

		}
	} else {
		p_stats->writes++;
		for (int i = 0; i < pow(2, cache_stats.s); i++) {
			if (cache[index][i].tag == tag && cache[index][i].valid)
				hit = true;
		}
		if (!hit) {
			p_stats->write_misses++;
			uint64_t lru_index = lru_matrix[index][0];
			cache[index][lru_index].tag = tag;
			cache[index][lru_index].index = index;
			cache[index][lru_index].offset = offset;
			cache[index][lru_index].valid = true;
			update_lru(index, cache_stats.s, lru_index);
		}
	}

	if (!hit)
		p_stats->misses++;

}

/**
 * Calculate hit time, miss penalty and miss rate according to the pdf instructions provided.
 */
void complete_cache(cache_stats_t *p_stats) {
	p_stats->hit_time = 0.2 * pow(2, cache_stats.s);
	p_stats->miss_penalty = p_stats->hit_time + 50 + 0.25 * pow(2, cache_stats.b - 1);
	p_stats->miss_rate = (double) p_stats->misses / p_stats->accesses; 
}
